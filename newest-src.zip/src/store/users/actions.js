export default {
    getUsers: () => {}
}