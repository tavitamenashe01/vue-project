import state from './state'
import actions from './actions'
export default {
    state,
    actions,
}