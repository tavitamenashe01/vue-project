export default {
    state: {
        posts: []
    },
    actions: {},
    mutations: {},
    getters: {}
}