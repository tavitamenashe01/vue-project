<template>
  <div class="main">
    <h1 class="title">Welcome to the Main Page!</h1>
    <router-link class="btn-services" to="/services" tag="button">Services</router-link>
  </div>
</template>


<script>
export default {};
</script>


<style>

</style>
